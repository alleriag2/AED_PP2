Arquivo zip gerado em: 08/06/2018 17:22:14 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: PP2 - Interpretador da Linguagem Kinojo